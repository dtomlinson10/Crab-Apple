﻿//class & properties for chores

using System;
using System.ComponentModel;
using System.Data.Common;

namespace CrapApple
{
    public class Chore : INotifyPropertyChanged
    {
        private string _id;
        public string ID
        {
            get { return _id; }
            set
            {
                _id = value;
                OnPropertyChanged(nameof(ID));
            }
        }

        private string _name;
        public string Name
        {
            get { return _name;}
            set
            {
                _name = value;
                OnPropertyChanged(nameof(Name));
            }
        }

        private string _description;
        public string Description
        {
            get { return _description; }
            set
            {
                _description = value;
                OnPropertyChanged(nameof(Description));
            }
        }

        private double _weight;
        public double Weight
        {
            get {return _weight; }
            set
            {
                _weight = value;
                OnPropertyChanged(nameof(Weight));
            }
        }

        private User _assignedUser;
        public User AssignedUser
        {
            get { return _assignedUser;}
            set
            {
                _assignedUser = value;
                OnPropertyChanged(nameof(AssignedUser));
            }
        }

        private DateOnly _dateOfCompletion;
        public DateOnly DateOfCompletion
        {
            get { return _dateOfCompletion;}
            set
            {
                _dateOfCompletion = value;
                OnPropertyChanged(nameof(DateOfCompletion));
            }
        }

        private bool _isCompleted;
        public bool IsCompleted
        {
            get { return _isCompleted; }
            set
            {
                _isCompleted = value;
                OnPropertyChanged(nameof(IsCompleted));
            }
        }

        private bool _isLate;
        public bool IsLate
        {
            get { return _isLate; }
            set
            {
                _isLate = value;
                OnPropertyChanged(nameof(IsLate));
            }
        }

        private bool _isChecked;
        public bool IsChecked
        {
            get { return _isChecked; }
            set
            {
                _isChecked = value;
                OnPropertyChanged(nameof(IsChecked));
            }
        }

        private int _estimatedTime;
        public int EstimatedTime
        {
            get { return _estimatedTime; }
            set
            {
                _estimatedTime = value;
                OnPropertyChanged(nameof(EstimatedTime));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            //signals propertychanged event, indicate which one has changed
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public Chore(string id, string name, string description, double weight, User assignedUser, DateOnly dateOfCompletion, bool isCompleted, bool isLate)
        {
            ID = id;
            Name = name;
            Description = description;
            Weight = weight;
            AssignedUser = assignedUser;
            DateOfCompletion = dateOfCompletion;
            IsCompleted = isCompleted;
            IsLate = isLate;
        }

        public void AddToDatabase(DbConnection connection)
        {
            //here: implement the method to add the chore to the database
            throw new NotImplementedException();
        }
    }
}