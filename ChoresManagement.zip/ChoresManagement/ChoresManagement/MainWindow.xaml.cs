﻿//handles init of main window

using CrapApple;
using System.Windows;
using System.Windows.Input;

namespace CrapApple
{
    // Partial class declaration for the main window
    public partial class MainWindow : Window
    {
        // Constructor for the main window
        public MainWindow()
        {
            // Initialize the component
            InitializeComponent();

            // Create an instance of the view model
            var viewModel = new MainWindowViewModel();

            // Set the CurrentUser property based on the logged-in user
            // Replace the following line with your logic to retrieve the logged-in user
            viewModel.CurrentUser = new RegularUser("001", "John", "Doe", "john.doe@example.com", "password");

            // Set the data context to the view model instance
            DataContext = viewModel;

            // Subscribe to the PreviewTextInput event of the weeklyChoresDataGrid
            weeklyChoresDataGrid.PreviewTextInput += WeeklyChoresDataGrid_PreviewTextInput;
        }

        // Event handler for the PreviewTextInput event of the weeklyChoresDataGrid
        private void WeeklyChoresDataGrid_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            // Validate the input text using the ValidateEstimatedTime method from InputValidationUtil
            // If input is not valid, set e.Handled to true to prevent the input from being processed
            e.Handled = !InputValidationUtil.ValidateEstimatedTime(e.Text, out _);
        }
    }
}